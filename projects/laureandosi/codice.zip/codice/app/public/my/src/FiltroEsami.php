<?php

namespace my\src;

class FiltroEsami
{
    public string $matricola;

    /** @var string[] $esami */
    public array $esamiNonInCurriculum;

    /** @var string[] $esami */
    public array $esamiNonInMedia;
}