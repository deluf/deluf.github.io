<?php

namespace my\src;

enum TipoEsame
{
    case STANDARD;
    case INFORMATICO;
}